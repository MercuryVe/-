function func=Rec_basis_function_2D(e_pos)
% 构造2D矩形插值基函数，
% 即F(t,s) = f1*K1(t,s) + f2*K2(t,s) + f3*K3(t,s)+f4*K4(s,t),
% 返回一个1*4的元胞数组，元素分别为4个基函数(K1,K2,K3,K4)。
    p=(e_pos(1,3)-e_pos(1,1)).*(e_pos(2,3)-e_pos(2,1));
    K1 = @(t,s)(t-e_pos(1,3)).*(s-e_pos(2,3))/p;
    K2 = @(t,s)(t-e_pos(1,4)).*(e_pos(2,4)-s)/p;
    K3 = @(t,s)(t-e_pos(1,1)).*(s-e_pos(2,1))/p;
    K4 = @(t,s)(e_pos(1,2)-t).*(s-e_pos(2,2))/p;
    func = cell(1,4);
    func{1} = K1;
    func{2} = K2;
    func{3} = K3;
    func{4} = K4;
end