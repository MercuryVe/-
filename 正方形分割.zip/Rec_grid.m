function [pos,T]=Rec_grid(X,Y,nx,ny)
% 矩形网格划分;
% 输入参数区间X,区间Y,nx为X中划分的区间个数，ny为Y中划分的区间个数；
% 输出参数pos为节点位置pos(：,i)为第i个节点的坐标，T为正方形网格划分后正方形的4个节点编号(连接矩阵，维度4*N)；
% 该矩阵每一列从上到下为逆时针节点位置；
% lenx与leny分别为X与Y划分后的节点数量；
hx = (X(2)-X(1))/nx;                                       
hy = (Y(2)-Y(1))/ny;
x = X(1):hx:X(2);
y = Y(1):hy:Y(2);
lenx = length(x);
leny = length(y);
pos = zeros(2,lenx*leny);
for i = 1:leny
    pos(1,(1 + (i-1)*lenx):i*(lenx)) = x;
    pos(2,(1 + (i-1)*lenx):i*(lenx)) = y(i);
end
T = zeros(4,(lenx-1)*(leny-1));
for i = 1:(lenx-1)*(leny-1)
    row = ceil(i/(lenx-1))-1;
    list = i - row * (lenx - 1);
    % 第 i 个正方形的四个顶点序号逆时针方向为 T_1,T_2,T_3,T_4;
    T(1,i) =row*lenx+list;
    T(2,i)=row*lenx+list+1;
    T(3,i) = (row+1)*lenx+list+1;
    T(4,i) = (row+1)*lenx + list;   
end