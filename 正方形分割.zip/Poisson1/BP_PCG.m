function [x,iter,res]=BP_PCG(A,B,C,A0,D,b,x0,eps,Max_iter)
%获得分块信息
n=size(B,2);
m=size(B,1);
%得到非标准内积
H=blkdiag(A-A0,D);
% disp(size(H));
%组装系数矩阵
A=[A,B';B,-C];
% disp(size(M));
%带入非标准内积PCG
res=zeros(Max_iter,1);
x=x0;
iter=0;
r=b-A*x0;
r1=r(1:n,1);
r2=r(n+1:n+m,1);
r1=A0\r1;
r2=(B*r1)-r2;
r2=D\r2;
r=[r1;r2];
p=r;
for k=1:Max_iter
    iter=iter+1;
    z=H*p;
    z1=z(1:n,1);
    z2=z(n+1:n+m,1);
    z2=-D'\z2;
    z1=z1-(B'*z2);
    z1=A0'\z1;
    z=[z1;z2];
    alpha=(r'*H*r)/(p'*A'*z);
    x=x+alpha*p;
    w=A*p;
    w1=w(1:n,1);
    w2=w(n+1:n+m,1);
    w1=A0\w1;
    w2=(B*w1)-w2;
    w2=D\w2;
    w=[w1;w2];
    R=r-alpha*w;
    res(k,1)=norm(R);
    if res(k,1)<eps
        disp("success");
        break;
    end
    beta=(R'*H*R)/(r'*H*r);
    p=R+beta*p;
    r=R;
end