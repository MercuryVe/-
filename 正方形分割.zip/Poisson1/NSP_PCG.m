function [x,iter,res]= NSP_PCG(A,b,x0,P_inv,H,eps,Max_iter)
%A系数矩阵，x_0初始值，P预处理子的逆，H内积，e容许误差
res=zeros(Max_iter,1);
x=x0;
iter=0;
r=(P_inv)*(b-A*x0);
p=r;
for k=1:Max_iter
    iter=iter+1;
    alpha=(r'*H*r)/(p'*A'*P_inv'*H*p);
    x=x+alpha*p;
    R=r-alpha*P_inv*A*p;
    res(k,1)=norm(R);
    if res(k,1)<eps
        disp("success");
        break;
    end
    beta=(R'*H*R)/(r'*H*r);
    p=R+beta*p;
    r=R;
end

