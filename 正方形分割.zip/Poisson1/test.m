clc,clear,close all
load M.mat,load b.mat,load K.mat
beta=1;
p_b=size(M,2);
Iter=zeros(2,10);
Z=zeros(p_b,p_b);
d=zeros(p_b,1);
%预处理GMRES与MINRES
% A=[beta*M,Z,-M;Z,M,K;-M,K,Z];
% A=sparse(A);
% b=[d;b;d];
% A_hat=[beta*M,Z;Z,M];
% B_hat=[-M,K];
% S_hat=(B_hat/A_hat)*B_hat';
% P1=blkdiag(A_hat,S_hat);
% P2=[A_hat,zeros(2*p_b,p_b);B_hat,-S_hat];
% [x_g1,iter_g1,res_g1]=Gmres(P1\A,P1\b,zeros(3*p_b,1),1e-10,3*p_b);
% [x_m1,iter_m1,res_m1]=Minres(P1\A,P1\b,zeros(3*p_b,1),1e-10,3*p_b);
% [x_g2,iter_g2,res_g2]=Gmres(P2\A,P2\b,zeros(3*p_b,1),1e-10,3*p_b);
% I1=1:iter_g1;
% J1=1:iter_m1;
% I2=1:iter_g2;
% 
% figure
% plot(I1,log10(res_g1(1:iter_g1,1)));
% hold on;
% plot(I2,log10(res_g2(1:iter_g2,1)));
% yticklabels({'1e-12','1e-10','1e-8','1e-6','1e-4','1e-2','1e-1'});
% legend('P1-GMRES','P2-GMRES');
% saveas(1,"(4.23)P1-GMRES与P2-GMRES的残差曲线.png");
% figure 
% plot(J1,res_m1(1:iter_m1,1));
% saveas(2,'(4.23)P1-MINRES的残差曲线.png');


%组装系数矩阵
% A=M;
% B=K;
% C=(-1/beta)*M;
% b=[b;d];
% D1=eye(p_b,p_b);
% S=(M+K)/M*(M+K);
% [x_rp,iter_rp,res_rp]=G_RPCG(A,B,-C,b,zeros(2*p_b,1),S,1e-10,3000);
% [x_BP2,iter_BP2,res_BP2]=BP_PCG(A,B,C,A/1.1,S,b,zeros(2*p_b,1),1e-10,3000);
% I=1:iter_rp;
% J=1:iter_BP2;
% figure
% plot(I,log10(res_rp(1:iter_rp,1)));
% hold on;
% plot(J,log10(res_BP2(1:iter_BP2,1)));
% yticklabels({'1e-12','1e-10','1e-8','1e-6','1e-4','1e-2','1','100'});
% legend('RPCG','BP-PCG');
% saveas(1,"n=32,第二种处理下地RPCG与BP-PCG收敛曲线.png");

% A=[M,K;K,(-1/beta)*M];
% [x_g,iter_g,res_g]=Gmres(A,b,zeros(2*p_b,1),1e-10,2*p_b);
% [x_m,iter_m,res_m]=Minres(A,b,zeros(2*p_b,1),1e-10,2*p_b);
% I=1:iter_g;
% J=1:iter_m;
% figure
% plot(I,log10(res_g(1:iter_g,1)));
% hold on
% plot(J,log10(res_m(1:iter_m,1)));
% yticklabels({'1e-13','1e-12','1e-10','1e-8','1e-6','1e-4','1e-2','1','10'});
% xticks([100,200,300,400,500,600,700]);
% legend('GMRES','MINRES');
% saveas(1,"问题(3.6)GMRES与MINRES收敛曲线.png");

% A=[M,K;K,(-1/beta)*M];
% b=[b;d];
% S=(K/M)*K+(1/beta)*M;
% P=blkdiag(M,S);
% [x_g,iter_g,res_g]=Gmres(P\A,P\b,zeros(2*p_b,1),1e-10,2*p_b);
% [x_m,iter_m,res_m]=Minres(P\A,P\b,zeros(2*p_b,1),1e-10,2*p_b);
% I=1:iter_g;
% J=1:iter_m;
% figure
% plot(I,log10(res_g(1:iter_g,1)));
% legend('P-GMRES');
% yticklabels({'1e-10','1e-9','1e-8','1e-7','1e-6','1e-5','1e-4','1e-3','1e-2','1e-1'});
% saveas(1,'问题(3.6)P-GMRES收敛曲线.png');
% figure
% plot(J,(res_m(1:iter_m,1)));
% legend('P-MINRES');
% saveas(2,"问题(3.6)P-MINRES收敛曲线.png");

%测试RPCG
A=[beta*M,Z;Z,M];
B=[-M,K];
S=(M+K)/M*(M+K);
b=[d;b;d];
[x_rp,iter_rp,res_rp]=RPCG(A,B,b,zeros(3*p_b,1),S,1e-10,3000);
[x_bp,iter_bp,res_bp]=BP_PCG(A,B,zeros(p_b,p_b),A/1.1,S,b,zeros(3*p_b,1),1e-10,3000);
I=1:iter_rp;
J=1:iter_bp;
figure
plot(I,log10(res_rp(1:iter_rp,1)));
hold on;
plot(J,log10(res_bp(1:iter_bp,1)));
yticklabels({'1e-12','1e-10','1e-8','1e-6','1e-4','1e-2','1','100'});
legend('RPCG','BP-PCG');
saveas(1,"n=32,第二种处理下地RPCG与BP-PCG收敛曲线.png");
