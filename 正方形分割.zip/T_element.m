function Te=T_element(E_pos,e_pos,w,delta)
Te=zeros(4,4);
[dx,dy]=diff_Rec_basis_fun(e_pos);
a=w(1,1);
b=w(2,1);
for i=1:4
    fx=dx{i};
    fy=dy{i};
    f = @(t,s) a*fx(t,s)+b*fy(t,s);
    f_hat=Projection_element(f,E_pos,e_pos);
    F = @(t,s) f(t,s)-f_hat(t,s);
    for j=1:4
        gx=dx{j};
        gy=dy{j};
        g = @(t,s) a*gx(t,s)+b*gy(t,s);
        g_hat=Projection_element(g,E_pos,e_pos);
        G = @(t,s) g(t,s) - g_hat(t,s);
        H = @(t,s) F(t,s).*G(t,s);
        Te(i,j)=delta*Rec_integral(H,e_pos);
    end
end




