clc,clear,close all
beta=1;
nx = 64;
ny = 64;
X = [0,1];
Y = [0,1];
hx = (X(2)-X(1))/nx;                                       
hy = (Y(2)-Y(1))/ny;
[pos,T] = Rec_grid(X,Y,nx,ny);
[~ ,p_b] = size(pos);%p_b为节点总数
[~ ,e_b] = size(T);%e_b为单元总数

% 右端函数
f = @(t,s) 2*pi^2*sin(pi*t).*sin(pi*s);
%state function
y = @(t,s) t+s;
% 构造荷载向量
F = zeros(p_b,1);
%构造state向量
b=zeros(p_b,1);
% 构造质量矩阵
M=sparse(p_b,p_b); 
% 构造刚度矩阵
K = sparse(p_b,p_b);
% 组装载荷，质量与刚度矩阵
for i = 1:e_b
    e_pos = pos(:,T(:,i));
    ke=element_stiffness(e_pos);
    me=element_mass(e_pos);
    b_func = Rec_basis_function_2D(e_pos);
    for j = 1:4
        b_f = b_func{j};
        state_f=@(t,s) b_f(t,s).*y(t,s);
        b_f = @(t,s) b_f(t,s).*f(t,s);
        F(T(j,i)) = F(T(j,i)) + Rec_integral(b_f,e_pos);
        b(T(j,i)) = b(T(j,i))+Rec_integral(state_f,e_pos);
        for k = 1:4
            K = K + sparse(T(j,i),T(k,i),ke(j,k),p_b,p_b);
            M = M + sparse(T(j,i),T(k,i),me(j,k),p_b,p_b);
        end
    end
end
%实验MINRES与GMRES的收敛性
%组装系数矩阵
Z=zeros(p_b,p_b);
d=zeros(p_b,1);
% A=[beta*M,Z,-M;Z,M,K;-M,K,Z];
% A=sparse(A);
% b=[d;b;d];
% [x_g,iter_g,res_g]=Gmres(A,b,zeros(3*p_b,1),1e-10,3*p_b);
% [x_m,iter_m,res_m]=Minres(A,b,zeros(3*p_b,1),1e-10,3*p_b);
% I=1:iter_g;
% J=1:iter_m;
% figure
% plot(I,log10(res_g(1:iter_g,1)));
% hold on
% plot(J,log10(res_m(1:iter_m,1)));
% yticklabels({'1e-12','1e-10','1e-8','1e-6','1e-4','1e-2'});
% xticks([0,500,1000,1500,2000,2500,3000,3500]);
% legend('GMRES','MINRES');
% saveas(1,"(4.23)GMRES与MINRES的残差曲线.png");
%实验BP_PCG
%组装测试矩阵
% A=[beta*M,Z;Z,M];
% B=[-M,K];
% C=Z;
% u=[d;b];
% v=d;
% D1=eye(p_b,p_b);
% D2=(B\A)*B'+C;
% for i=1:10
% [x_BP1,iter_BP1]=BP_PCG(A,B,C,A/1.1,D1,[u;v],zeros(3*p_b,1),10^(-i),3000);
% [x_BP2,iter_BP2]=BP_PCG(A,B,C,A/1.1,D2,[u;v],zeros(3*p_b,1),10^(-i),3000);
% Iter(1,i)=iter_BP1;
% Iter(2,i)=iter_BP2;
% end
% [x_BP1,iter_BP1,res_bp1]=BP_PCG(A,B,C,A/1.1,D1,[u;v],zeros(3*p_b,1),1e-10,3000);
% [x_BP2,iter_BP2,res_bp2]=BP_PCG(A,B,C,A/1.1,D2,[u;v],zeros(3*p_b,1),1e-10,3000);
% I=1:iter_BP1;
% J=1:iter_BP2;
% figure
% plot(I,log10(res_bp1(1:iter_BP1,1)));
% yticklabels({'1e-12','1e-10','1e-8','1e-6','1e-4','1e-2','1e-1','1'});
% xticks([0,200,400,600,800,1000]);
% saveas(1,"BP1-PCG收敛曲线.png");
% figure
% plot(J,log10(res_bp2(1:iter_BP2,1)));
% yticklabels({'1e-12','1e-10','1e-8','1e-6','1e-4','1e-2','1e-1','1'});
% xticks([1,2,3,4,5,6]);
% saveas(2,"BP2-PCG收敛曲线.png");

