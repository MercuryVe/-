clc,clear,close all;
load b.mat;
load F1.mat;
load M.mat;
n=size(M,2);
Z=zeros(n,n);
z=zeros(n,1);
b=[b;z];
A0=M/1.1;
S=(F1+M)/M*(F1'+M);
[x_bp,iter_bp,res_bp]=BP_PCG(M,F1,M,A0,S,b,zeros(2*n,1),1e-10,3000);
[x_rp,iter_rp,res_rp]=G_RPCG(M,F1,M,b,zeros(2*n,1),S,1e-10,3000);
I=1:iter_bp;
J=1:iter_rp;
figure
plot(I,log10(res_bp(1:iter_bp,1)));
yticklabels({'1e-12','1e-10','1e-8','1e-6','1e-4','1e-2','1','10'});
hold on
plot(J,log10(res_rp(1:iter_rp,1)));
legend('BP-PCG','RPCG');
saveas(1,'第三种情况的BP-PCG与RPCG收敛曲线.png');