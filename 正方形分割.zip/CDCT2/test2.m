clc,clear,close all;
load b.mat;
load F1.mat;
load M.mat;
n=size(M,2);
Z=zeros(n,n);
z=zeros(n,1);
b=[b;z;z];
A=[M,Z;Z,M];
B=[F1,-M];
C=Z;
S=(F1+M)/M*(F1'+M);
A0=A/1.1;
D1=eye(n);
D2=S;
%[x_bp1,iter_bp1,res_bp1]=BP_PCG(A,B,C,A0,D1,b,zeros(3*n,1),1e-10,3000);
[x_bp2,iter_bp2,res_bp2]=BP_PCG(A,B,C,A0,D2,b,zeros(3*n,1),1e-10,3000);
[x_rp,iter_rp,res_rp]=RPCG(A,B,b,zeros(3*n,1),S,1e-10,3000);
I=1:iter_rp;
J=1:iter_bp2;
figure
plot(J,log10(res_bp2(1:iter_bp2,1)));
hold on
plot(I,log10(res_rp(1:iter_rp,1)));
yticklabels({'1e-12','1e-10','1e-8','1e-6','1e-4','1e-2','1','10'});
legend('BP-PCG','RPCG');
saveas(1,'(4.28)第二种情况的BP-PCG与RPCG收敛曲线.png');
% figure
% plot(J,log10(res_bp2(1:iter_bp2,1)));
% yticklabels({'1e-12','1e-10','1e-8','1e-6','1e-4','1e-2','1e-0','1e1'});
% legend('BP-PCG');
% saveas(1,'(4.28)BP-PCG收敛曲线.png');