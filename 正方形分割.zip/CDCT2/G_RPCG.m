function [x,iter,res]= G_RPCG(A,B,C,b,x0,S,eps,Max_iter)
iter=0;
x=x0;
res=zeros(Max_iter,1);
[m,n]=size(B);
M=[A,B';B,-C];
r=b-M*x0;
r1=r(1:n,1);
r2=r(n+1:n+m,1);
t1=A\r1;
t2=B*t1-r2;
z2=S\t2;
z1=A\(r1-B'*z2);
z=[z1;z2];
p=z;
w=B'*z2;
w=2*(A\w);
v=[z1+w;-z2];
q=v;
for i=1:Max_iter
    iter=iter+1;
    alpha=-(v'*r)/(q'*M*p);
    x=x-alpha*p;
    R=r+alpha*M*p;
    res(iter,1)=norm(R);
    if res(iter,1)<eps
        disp('success');
        break;
    end
    r1=R(1:n,1);
    r2=R(n+1:n+m,1);
    t1=A\r1;
    t2=B*t1-r2;
    z2=S\t2;
    z1=A\(r1-B'*z2);
    w=B'*z2;
    w=2*(A\w);
    V=[z1+w;-z2];
    Z=[z1;z2];
    beta=(V'*R)/(v'*r);
    z=Z;
    v=V;
    r=R;
    p=z+beta*p;
    q=v+beta*q;
end

    

