function [x, iter_count] = PCG(A, b, P, x0, tol)

% PCG 使用预处理共轭梯度法求解线性方程组Ax = b，基于用户给定的预处理子P和初始向量x0
% 输入参数:
%   A: 系数矩阵，要求是对称正定矩阵
%   b: 右端项向量
%   P: 预处理子矩阵
%   x0: 初始向量
%   tol: 收敛容差，默认值为1e-6
% 输出参数:
%   x: 方程组的解向量
%   iter_count: 迭代次数

    if nargin < 5
        tol = 1e-6; % 如果用户未指定收敛容差，默认设为1e-6
    end
    
    % 使用用户传入的初始向量x0
    x = x0;
    
    % 初始化残差向量
    r = b - A * x;

    
    % 初始化搜索方向向量
    z = P\r;
    p = z;
    
    % 初始化迭代次数
    iter_count = 0;
    
    
    % 预处理共轭梯度法迭代求解
    while norm(r) > tol
        iter_count = iter_count + 1;
        
        % 计算步长
        alpha = (r' * z) / (p' * A * p);
        
        % 更新解向量
        x = x + alpha * p;
        
        % 更新残差向量
        r_new = r - alpha * A * p;
        
        % 计算新的预处理后的残差向量
        z_new = P\r_new;
        
        % 计算beta值
        beta = (r_new' * z_new) / (r' * z);
        
        % 更新搜索方向向量
        p = z_new + beta * p;
        
        % 更新残差向量和预处理后的残差向量
        r = r_new;
        z = z_new;
    end
end