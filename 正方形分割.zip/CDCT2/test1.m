clc,clear,close all;
load b.mat;
load F1.mat;
load M.mat;
n=size(M,2);
Z=zeros(n,n);
z=zeros(n,1);
A=[M,Z;Z,M];
B=[F1,-M];
S=(B/A)*B';
P1=blkdiag(A,S);
P2=[A,zeros(2*n,n);B,-S];
A=[M,Z,F1';Z,M,-M;F1,-M,Z];
b=[b;z;z];
[x_g,iter_g,res_g]=Gmres(P2\A,P2\b,zeros(3*n,1),1e-10,3*n);
[x_m,iter_m,res_m]=Minres(P2\A,P2\b,zeros(3*n,1),1e-10,3*n);
I=1:iter_g;
J=1:iter_m;
figure
plot(I,log10(res_g(1:iter_g,1)));
yticklabels({'1e-12','1e-10','1e-8','1e-6','1e-4','1e-2','1e-0','1e1'});
legend('P2-GMRES');
saveas(1,'(4.28)P2-GMRES收敛曲线.png');
figure
plot(J,res_m(1:iter_m,1));
legend('P2-MINRES');
saveas(2,'(4.28)P2-MINRES收敛曲线.png');





