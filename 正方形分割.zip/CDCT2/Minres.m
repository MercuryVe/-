function [x,iter,res]=Minres(A,b,x0,eps,Max_Iter)
%A是系数矩阵x0为初始向量，eps为精度要求，Max_Iter是最大迭代数
if nargin < 5
    Max_Iter=1000;
end

if nargin < 4
    eps=1e-6;
end
res=zeros(Max_Iter,1);
x=x0;
iter=0;
n=size(A,2);
r=b-A*x0;
a=norm(r);
q_old=zeros(n,1);
q_new=r/a;
d_old=zeros(n,1);
d_mid=zeros(n,1);
xi_old=a;
beta_old=0;
r_old=0;
r_mid=0;
c_old=0;
c_mid=0;
s_old=0;
s_mid=0;
ls=zeros(Max_Iter,Max_Iter);
for k=1:Max_Iter
    iter=iter+1;
    w=A*q_new-beta_old*q_old;
    alpha=w'*q_new;
    w=w-alpha*q_new;
    beta_new=norm(w);

    if k==1
        alpha_hat=alpha;
    elseif k==2
            r_mid=c_mid*beta_old+s_mid*alpha;
            alpha_hat=-s_mid*beta_old+c_mid*alpha;
    else
        r_old=s_old*beta_old;
        beta_hat=c_old*beta_old;

        r_mid=c_mid*beta_hat+s_mid*alpha;
        alpha_hat=-s_mid*beta_hat+c_mid*alpha;
    end

    if abs(alpha_hat)>abs(beta_new)
        gamma=beta_new/alpha_hat;
        c_new=1/sqrt(1+gamma^2);
        s_new=c_new*gamma;
    else
        gamma=alpha_hat/beta_new;
        s_new=1/sqrt(1+gamma^2);
        c_new=s_new*gamma;
    end

    r_new=c_new*alpha_hat+s_new*beta_new;

    xi_new=-s_new*xi_old;
    xi_old=c_new*xi_old;

    d_new=(q_new-r_old*d_old-r_mid*d_mid)/r_new;
    x=x+xi_old*d_new;
    ls(:,k+1)=q_new;
    res(iter,1)=abs(xi_new);
    if abs(xi_new)<eps
        disp(['最终残差为',num2str(abs(xi_new))]);
        break
    else
        xi_old=xi_new;
        q_old=q_new;
        q_new=w/beta_new;

        beta_old=beta_new;
        c_old=c_mid;
        c_mid=c_new;
        s_old=s_mid;
        s_mid=s_new;

        r_old=r_mid;
        r_mid=r_new;

        d_old=d_mid;
        d_mid=d_new;
    end
end
if iter==Max_Iter
    disp("无法收敛");
end

   







       








