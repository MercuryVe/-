function [x, iter,res] = Gmres(A, b, x0, eps , max_iter)
%A是系数矩阵x0为初始向量，eps为精度要求，Max_Iter是最大迭代数
if nargin < 5
max_iter=1000;
end
if nargin < 4
    eps=1e-6;
end
res=zeros(max_iter,1);%记录残差
iter=0;
n=size(A,2);

H=zeros(max_iter+1,max_iter);%海森堡矩阵
V=zeros(n,max_iter);%储存正交基
G=zeros(2,2*max_iter);%储存Givens变换

r0=b-A*x0;
beta=norm(r0);
v1=r0/beta;
V(:,1)=v1;
E=eye(n);
xi=beta*E(:,1);%用于计算和存放q1

if beta/norm(b)<eps
    x=x0;
    iter=0;
end

for j=1:max_iter
iter=iter+1;
w=A*V(:,j);
for i=1:j
H(i,j)=w'*V(:,i);
w=w-H(i,j)*V(:,i);
end
H(j+1,j)=norm(w);
if H(j+1,j)==0
     disp(['中途终止于第',num2str(iter),'步']);
    break;
end
V(:,j+1)=w/H(j+1,j);
for i=1:j-1
    H(i:i+1,j)=G(1:2,2*i-1:2*i)*H(i:i+1,j);
end
if abs(H(j,j))>abs(H(j+1,j))
    t=H(j+1,j)/H(j,j);
    c=1/sqrt(1+t*t);
    s=c*t;
else
    t=H(j,j)/H(j+1,j);
    s=1/sqrt(1+t*t);
    c=s*t;
end
G(1:2,2*j-1:2*j)=[c,s;-s,c];

H(j,j)=c*H(j,j)+s*H(j+1,j);
H(j+1,j)=0;
xi(j:j+1,1)=G(1:2,2*j-1:2*j)*xi(j:j+1,1);
res(iter,1)=abs(xi(iter+1));
if abs(res(iter,1))/beta<eps
    disp(['最终残差为',num2str(xi(iter+1))]);
    break;
end
end
R=H(1:iter,1:iter);
xi_m=xi(1:iter);
y=R\xi_m;
x=x0+V(:,1:iter)*y;
end