function [x,iter,res]=RPCG(A,B,b,x0,G,eps,Max_iter)
%只能针对鞍点问题求解
x=x0;
iter=0;
res=zeros(Max_iter,1);
n=size(A,2);
m=size(B,1);
C=[A,B';B,zeros(m,m)];
r=b-C*x;
r1=r(1:n,1);
r2=r(n+1:n+m,1);
t1=A\r1;
z2=G\(r2-B*t1);
t1_hat=A\(B'*z2);
z1=t1-t1_hat;
z=[z1;z2];
p=z;

for k=1:Max_iter
    
    iter=iter+1;
    alpha=-(z'*r)/(p'*C*p);
    %disp(alpha);
    x=x-alpha*p;
    R=r+alpha*C*p;
    res(k,1)=norm(R);

    if res(k,1) < eps
        disp('success');
        break;
    end 

    R1=R(1:n,1);
    R2=R(n+1:n+m,1);
    t1=A\R1;
    Z2=G\(R2-B*t1);
    t1_hat=A\(B'*Z2);
    Z1=t1-t1_hat;
    Z=[Z1;Z2];
    beta=(Z'*R)/(z'*r);
    p=Z+beta*p;
    z=Z;
    r=R;
end

