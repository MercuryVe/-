function ke=element_stiffness(e_pos)
%单元刚度矩阵e_pos为单元端点的位置
ke=zeros(4,4);
[funcx,funcy]=diff_Rec_basis_fun(e_pos);
for i=1:4
    fx=funcx{i};
    fy=funcy{i};
    for j=1:4
        gx=funcx{j};
        gy=funcy{j};
        element_f = @(t,s) fx(t,s).*gx(t,s) + fy(t,s).*gy(t,s);
        ke(i,j)=Rec_integral(element_f,e_pos);
    end
end

end