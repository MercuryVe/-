function Func=Orth_Basis_element(e_pos)
%计算每个单元内基函数的正交基
h=(e_pos(1,3)-e_pos(1,1));
func=Rec_basis_function_2D(e_pos);
f1=func{1};
f2=func{2};
f3=func{3};
f4=func{4};
f1_hat=@(t,s) (3*f1(t,s))/h;
f2_hat=@(t,s) (2*sqrt(3)/h)*(f2(t,s)-0.5*f1(t,s));
f3_hat=@(t,s) (2*sqrt(3)/h)*(f3(t,s)-0.5*f2(t,s));
f4_hat=@(t,s) (4*f4(t,s)-2*f1(t,s)+f2(t,s)-2*f3(t,s))/h;
Func=cell(1,4);
Func{1}=f1_hat;
Func{2}=f2_hat;
Func{3}=f3_hat;
Func{4}=f4_hat;
end



