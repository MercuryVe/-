clc,clear,close all
beta=1;
eps=0.001;
w=[0.3;0.4];
nx = 64;
ny = 64;
X = [0,1];
Y = [0,1];
hx = (X(2)-X(1))/nx;                                       
hy = (Y(2)-Y(1))/ny;
Pe=hx*0.5/eps;
delta=0;
if Pe >1
    delta=hx*2;
end

[pos,T] = Rec_grid(X,Y,nx,ny);
[~ ,p_b] = size(pos);%p_b为节点总数
[~ ,e_b] = size(T);%e_b为单元总数

%粗糙网格的格点坐标与链接矩阵
[pos_c,T_c] = Rec_grid(X,Y,nx/2,ny/2);
[~ ,p_b_c] = size(pos_c);
[~ ,e_b_c] = size(T_c);

% 右端函数
f = @(t,s) 2*pi^2*sin(pi*t).*sin(pi*s);
%state function
y = @(t,s) t+s;
% 构造荷载向量
F = zeros(p_b,1);
%构造state向量
b=zeros(p_b,1);
% 构造质量矩阵
M=sparse(p_b,p_b); 
% 构造刚度矩阵
K = sparse(p_b,p_b);
%构造N与T
N = sparse(p_b,p_b);
T1 = sparse(p_b,p_b);
% 组装载荷，质量与刚度矩阵
for i = 1:e_b
    e_pos = pos(:,T(:,i));
    ke=element_stiffness(e_pos);
    me=element_mass(e_pos);
    b_func = Rec_basis_function_2D(e_pos);
    %确定该单元在更粗糙网格中的位置
    row=ceil(i/ny);
    col=ny-(row*ny-i);
    row_c=ceil(row/2);
    col_c=ceil(col/2);
    i_c=(row_c-1)*(ny/2)+col_c;
    E_pos=pos_c(:,T_c(:,i_c));

    te=T_element(E_pos,e_pos,w,delta);
    ne=N_element(E_pos,e_pos);
    for j = 1:4
        b_f = b_func{j};
        state_f=@(t,s) b_f(t,s).*y(t,s);
        b_f = @(t,s) b_f(t,s).*f(t,s);
        F(T(j,i)) = F(T(j,i)) + Rec_integral(b_f,e_pos);
        b(T(j,i)) = b(T(j,i))+Rec_integral(state_f,e_pos);
        for k = 1:4
            K = K + sparse(T(j,i),T(k,i),ke(j,k),p_b,p_b);
            M = M + sparse(T(j,i),T(k,i),me(j,k),p_b,p_b);
            N = N + sparse(T(j,i),T(k,i),ne(j,k),p_b,p_b);
            T1 = T1 + sparse(T(j,i),T(k,i),te(j,k),p_b,p_b);
        end
    end
end
F1=eps*K+N+T1;
