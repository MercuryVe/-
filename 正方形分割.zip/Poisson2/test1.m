clc,clear,close all
load M.mat,load b.mat,load K.mat
beta=1;
p_b=size(M,2);
Iter=zeros(2,10);
Z=zeros(p_b,p_b);
d=zeros(p_b,1);
%预处理GMRES与MINRES
A=[beta*M,Z,-M;Z,M,K;-M,K,Z];
A=sparse(A);
b=[d;b;d];
A_hat=[beta*M,Z;Z,M];
B_hat=[-M,K];
S_hat=(B_hat/A_hat)*B_hat';
P1=blkdiag(A_hat,S_hat);
P2=[A_hat,zeros(2*p_b,p_b);B_hat,-S_hat];
[x_g1,iter_g1,res_g1]=Gmres(P1\A,P1\b,zeros(3*p_b,1),1e-10,3*p_b);
%[x_m1,iter_m1,res_m1]=Minres(P1\A,P1\b,zeros(3*p_b,1),1e-10,3*p_b);
[x_g2,iter_g2,res_g2]=Gmres(P2\A,P2\b,zeros(3*p_b,1),1e-10,3*p_b);
I1=1:iter_g1;
%J1=1:iter_m1;
I2=1:iter_g2;

figure
plot(I1,log10(res_g1(1:iter_g1,1)));
hold on;
plot(I2,log10(res_g2(1:iter_g2,1)));
yticklabels({'1e-12','1e-10','1e-8','1e-6','1e-4','1e-2','1e-1'});
legend('P1-GMRES','P2-GMRES')
saveas(1,"(4.23)P1-GMRES与P2-GMRES的残差曲线.png");


