clc,clear,close all;
load M.mat,load b.mat,load K.mat
beta=1;
p_b=size(M,2);
Iter=zeros(2,10);
Z=zeros(p_b,p_b);
d=zeros(p_b,1);
b=[d;b;d];
A=[beta*M,Z;Z,M];
B=[-M,K];
S=(M+K)/M*(M+K');
C=zeros(p_b,p_b);
[x_BP,iter_BP,res_BP]=BP_PCG(A,B,C,A/1.1,S,b,zeros(3*p_b,1),1e-10,3000);
[x_rp,iter_rp,res_rp]=RPCG(A,B,b,zeros(3*p_b,1),S,1e-10,3000);
J=1:iter_BP;
K=1:iter_rp;
figure
plot(J,log10(res_BP(1:iter_BP,1)));
hold on;
plot(K,log10(res_rp(1:iter_rp,1)));
yticklabels({'1e-12','1e-10','1e-8','1e-6','1e-4','1e-2','1','10','100'});
legend('BP-PCG','RPCG');
saveas(1,"问题(3.6)BP-PCG与RPCG收敛曲线(第二种处理方式).png");