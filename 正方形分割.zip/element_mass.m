function me=element_mass(e_pos)
%单元质量矩阵
me=zeros(4,4);
func=Rec_basis_function_2D(e_pos);
for i=1:4
    k1=func{i};
    for j=1:4
        k2=func{j};
        k=@(t,s) k1(t,s).*k2(t,s);
        me(i,j)=Rec_integral(k,e_pos);
    end
end
end
