function Ne=N_element(e_pos,w)
Ne=zeros(4,4);
fun=Rec_basis_function_2D(e_pos);
[dx,dy]=diff_Rec_basis_fun(e_pos);
for i=1:4
    f=fun{i};
    for j=1:4
        fx=dx{j};
        fy=dy{j};
        g = @(t,s) (w(1,1)*fx(t,s)+w(2,1)*fy(t,s)).*f(t,s);
        Ne(i,j)=Rec_integral(g,e_pos);
    end
end


