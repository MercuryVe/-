function f_hat=Projection_element(f,E_pos,e_pos)
%函数在更加稀疏的网格基函数空间上的投影。
func=Orth_Basis_element(E_pos);
c=zeros(4,1);
f_hat=@(t,s) 0*(t+s);
for i=1:4
    g=func{i};
    h=@(t,s) f(t,s).*g(t,s);
    c(i,1)=Rec_integral(h,e_pos);
    f_hat=@(t,s) f_hat(t,s)+h(t,s);
end
