function [dx,dy] = diff_Rec_basis_fun(e_pos)
% 构造插值基函数的偏导数分别为K1x,K1y,K2x,K2y,K3x,K3y，K4x,K4y
% 注意到每个函数中都有(t-t+s-s)这样的一个和式，这并不影响函数本身的值
% 但在使用过程中，他将产生和输入一样维数的输出
    p = (e_pos(1,3)-e_pos(1,1)).*(e_pos(2,3)-e_pos(2,1));
    K1x =@(t,s)t-t+s-s+(s-e_pos(2,3))/p;
    K2x =@(t,s)t-t+s-s+(e_pos(2,4)-s)/p;
    K3x =@(t,s)t-t+s-s+(s-e_pos(2,1))/p;
    K4x =@(t,s)t-t+s-s+(e_pos(2,2)-s)/p;
    K1y =@(t,s)t-t+s-s+(t-e_pos(1,3))/p;
    K2y =@(t,s)t-t+s-s+(e_pos(1,4)-t)/p;
    K3y =@(t,s)t-t+s-s+(t-e_pos(1,1))/p;
    K4y =@(t,s)t-t+s-s+(e_pos(1,2)-t)/p;
    dx = cell(1,4);
    dy = cell(1,4);
    dx{1} = K1x;
    dx{2} = K2x;
    dx{3} = K3x;
    dx{4} = K4x;
    dy{1} = K1y;
    dy{2} = K2y;
    dy{3} = K3y;
    dy{4} = K4y;
end
