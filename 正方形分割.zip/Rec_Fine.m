clc,clear,close all
nx = 16;
ny = 16;
X = [0,1];
Y = [0,1];
hx = (X(2)-X(1))/nx;                                       
hy = (Y(2)-Y(1))/ny;
[pos,T] = Rec_grid(X,Y,nx,ny);
[~ ,p_b] = size(pos);%p_b为节点总数
[~ ,e_b] = size(T);%e_b为单元总数

% 右端函数
f = @(t,s) 2*pi^2*sin(pi*t).*sin(pi*s);
%state function
y = @(t,s) t+s;
% 构造荷载向量
F = zeros(p_b,1);
%构造state向量
b=zeros(p_b,1);
% 构造质量矩阵
M=sparse(p_b,p_b); 
% 构造刚度矩阵
A = sparse(p_b,p_b);
% 组装载荷，质量与刚度矩阵
for i = 1:e_b
    e_pos = pos(:,T(:,i));
    ke=element_stiffness(e_pos);
    me=element_mass(e_pos);
    b_func = Rec_basis_function_2D(e_pos);
    for j = 1:4
        b_f = b_func{j};
        state_f=@(t,s) b_f(t,s).*y(t,s);
        b_f = @(t,s) b_f(t,s).*f(t,s);
        F(T(j,i)) = F(T(j,i)) + Rec_integral(b_f,e_pos);
        b(T(j,i)) = b(T(j,i))+Rec_integral(state_f,e_pos);
        for k = 1:4
            A = A + sparse(T(j,i),T(k,i),ke(j,k),p_b,p_b);
            M = M + sparse(T(j,i),T(k,i),me(j,k),p_b,p_b);
        end
    end
end


 %修改边界条件
  bound_xl = find(pos(1,:) == X(1));
  bound_xr = find(pos(1,:) == X(2));
  bound_yd = find(pos(2,:) == Y(1));
  bound_yu = find(pos(2,:) == Y(2));
  e = eye(p_b);%p_b*p_b的单位阵
  
  i_point = intersect(union(bound_yd,bound_yu),union(bound_xr,bound_xl));
  A(i_point,:) = e(i_point,:);
  A(:,i_point) = e(:,i_point);

  %获取边界点的位置

  bound = union(union(bound_yd,bound_yu),union(bound_xr,bound_xl));

  for i = 1:length(bound)
      A(bound(i),:) = e(bound(i),:);
      A(:,bound(i)) = e(:,bound(i));
      F(bound(i)) = 0;
  end

%求解方程Ax=F;
u = A\F;

%获得数值解在每个个点的取值储存在矩阵U中
U = zeros(ny+1,nx+1); 
for i = 1:(ny+1)
    U(i,:) = u((i-1)*(nx+1)+1:i*(nx+1));
end

%绘制数值解图像
figure
[gridX,gridY] = meshgrid(X(1):hx:X(2),Y(1):hy:Y(2));
mesh(gridX,gridY,U)
F_k = @(x,y)sin(pi*x).*sin(pi*y);
colormap(parula(5))

%绘制误差图像
figure
mesh(gridX,gridY,F_k(gridX,gridY)-U)
colormap(parula(5))
