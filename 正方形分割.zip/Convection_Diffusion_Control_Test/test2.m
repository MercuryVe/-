clc,clear,close all;
load b.mat;
load F1.mat;
load M.mat;
n=size(M,2);
Z=zeros(n,n);
z=zeros(n,1);
b=[b;z;z];
A=[M,Z;Z,M];
B=[F1,-M];
C=Z;
S=(F1+M)/M*(F1'+M);
A0=A/1.1;
[x_rp,iter_rp,res_rp]=RPCG(A,B,b,zeros(3*n,1),S,1e-10,3000);
[x_bp2,iter_bp2,res_bp2]=BP_PCG(A,B,C,A0,S,b,zeros(3*n,1),1e-10,3000);
I=1:iter_rp;
J=1:iter_bp2;
figure
plot(I,log10(res_rp(1:iter_rp,1)));
yticklabels({'1e-12','1e-10','1e-8','1e-6','1e-4','1e-2','1e-0','1e1'});
hold on
plot(J,log10(res_bp2(1:iter_bp2,1)));
legend('RPCG','BP-PCG');
saveas(1,'n=32时对流扩散约束优化的RPCG与BP-PCG收敛曲线(第二种处理).png');