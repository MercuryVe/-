clc,clear,close all;
load b.mat;
load F1.mat;
load M.mat;
n=size(M,2);
Z=zeros(n,n);
z=zeros(n,1);
A=[M,Z;Z,M];
B=[F1,-M];
S=(B/A)*B';
P1=blkdiag(A,S);
P2=[A,zeros(2*n,n);B,-S];
A=[M,Z,F1';Z,M,-M;F1,-M,Z];
b=[b;z;z];
[x_g1,iter_g1,res_g1]=Gmres(P1\A,P1\b,zeros(3*n,1),1e-10,3*n);
[x_g2,iter_g2,res_g2]=Gmres(P2\A,P2\b,zeros(3*n,1),1e-10,3*n);
I=1:iter_g1;
J=1:iter_g2;
figure
plot(I,log10(res_g1(1:iter_g1,1)));
hold on;
plot(J,log10(res_g2(1:iter_g2,1)));
yticklabels({'1e-16','1e-14','1e-12','1e-10','1e-8','1e-6','1e-4','1e-2','1','100'});
legend('P1-GMRES','P2-GMRES');
saveas(1,'(4.28)P1-GMRES与P2-GMRES收敛曲线.png');




