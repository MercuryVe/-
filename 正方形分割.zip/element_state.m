function be=element_state(e_pos,y)
be=zeros(4,1);
func=Rec_basis_function_2D(e_pos);
for i=1:4
f=func(i);    
g=@(t,s) f(t,s).*y(t,s);
be(i,1)=Rec_integral(g,e_pos);
end
end